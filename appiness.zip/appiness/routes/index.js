var express = require('express');
var router = express.Router();
var knex= require('../connection') //knex is a query builder

/* GET home page. */
router.post('/insert', function(req, res, next) {
  var req = req.body;
  //fetch the all data from user_table
 knex.raw('select * from user_table').then(function(result){
   console.log(result.rowCount)
   //if table is empty then  insert data as an admin type
   if(result.rowCount==0){
     knex.raw("insert into user_table(user_id,user_admin,password)values(?,'Admin',?)",[req.user,req.password]).then(function(response){
         console.log("1st user insereted")
         res.send("1st user insereted")
     })
   }else{ //  insert data as an user type
    knex.raw("insert into user_table(user_id,user_admin,password)values(?,'user',?)",[req.user,req.password]).then(function(response){
      console.log(" users insereted")
      res.send("users insereted")

    })

   }
 })
});

module.exports = router;
